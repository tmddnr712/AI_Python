from karel.stanfordkarel import *

"""
File: BeeperCollectingKarel.py
------------------------
The BeeperCollectingKarel class collects all the beepers
in a series of vertical towers and deposits them at the
eastmost corner on 1st row.
"""


def main():
    """
    You should write your code to make Karel do its task in
    this function. Make sure to delete the 'pass' line before
    starting to write your own code. You should also delete this
    comment and replace it with a better, more descriptive one.
    """
    collect_all_beepers()
    drop_all_beepers()
    return_home()

def collect_all_beepers():#1
    while front_is_clear():
        collect_one_tower()
        move()
    collect_one_tower()

def drop_all_beepers():#4
    while beepers_in_bag():
        put_beeper()

def collect_one_tower():#2
    turn_left()
    collect_line_of_beepers()
    turn_around()
    move_to_wall()
    turn_left()

def collect_line_of_beepers():#3
    while beepers_present():
        pick_beeper()
        if front_is_clear():
            move()

def turn_around():#7
    turn_left()
    turn_left()

def move_to_wall():#6
    while front_is_clear():
        move()

def return_home():#5
    turn_around()
    move_to_wall()
    turn_around()

# There is no need to edit code beyond this point

if __name__ == "__main__":
    run_karel_program()
