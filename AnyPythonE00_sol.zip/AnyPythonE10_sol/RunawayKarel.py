from karel.stanfordkarel import *

"""
File: RunwayKarel.py
------------------------
The RunawayKarel class makes Karel run away to the wall.
The class asks a user which direction a Karel is running
away, i.e., either East, West, South, or North. Then, 
a Karel is moving to the wall with the direction.
Extra: After arriving at the edge, put beepers as many Karel moved.
For example, if Karel moved 2 corners, put 2 beepers.
"""


def main():
    """
    You should write your code to make Karel do its task in
    this function. Make sure to delete the 'pass' line before
    starting to write your own code. You should also delete this
    comment and replace it with a better, more descriptive one.
    """
    dir = input('Which direction does Karel move? (E, W, S, or N)')

    if dir == 'N':
        turn_left()
    elif dir == 'W':
        turn_left()
        turn_left()
    elif dir == 'S':
        turn_left()
        turn_left()
        turn_left()

    while front_is_clear():
        move()

# There is no need to edit code beyond this point

if __name__ == "__main__":
    run_karel_program()
