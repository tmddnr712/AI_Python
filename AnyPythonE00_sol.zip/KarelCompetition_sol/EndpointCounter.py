from karel.stanfordkarel import *

"""
File: EndpointCounter.py
------------------------
In this problem, Karel is in the top left corner of a 
square world. Karel needs to make his way down to a staircase
at the bottom left corner, and from there, he needs to place 
the same number of beepers on each step as there are blank 
spaces above Karel. For example, in a 10x10 world, karel must 
place 9 beepers on the first step (due to 1 being blocked by
a wall), then 8 in the next, and so on, until Karel reaches 
the top of the staircase.  
"""

def main():
    """
    You should write your code to make Karel do its task in
    this function. Make sure to delete the 'pass' line before
    starting to write your own code. You should also delete this
    comment and replace it with a better, more descriptive one.
    """
    pass

#move function
def move_to_wall():
    while front_is_clear():
        move()


def turn_right():
    turn_left()
    turn_left()
    turn_left()


def turn_around():
    turn_left()
    turn_left()
# There is no need to edit code beyond this point
if __name__ == "__main__":
    run_karel_program()
