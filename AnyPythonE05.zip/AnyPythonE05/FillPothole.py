from karel.stanfordkarel import *

"""
File: FillPothall.py
------------------------
Fills the pothole beneath Karel's current position by 
placing a beeper on that corner. For this function to work 
correctly, Karel must be facing east immediately above the 
pothole. When execution is complete, Karel will have 
returned to the same square and will again be facing east.
"""


def main():
    """
    You should write your code to make Karel do its task in
    this function. Make sure to delete the 'pass' line before
    starting to write your own code. You should also delete this
    comment and replace it with a better, more descriptive one.
    """
    pass

# There is no need to edit code beyond this point

if __name__ == "__main__":
    run_karel_program()
